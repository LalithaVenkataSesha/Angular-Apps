import { Directive,ElementRef,HostListener,Renderer2,Output,EventEmitter, Input, Optional } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductModel } from './models/product-model';
// import { PRODUCTS } from './models/mock-model-list';


@Directive({
  selector: '[appAddButton]'
})
export class AddButtonDirective {
  // public products = ProductModel;
  constructor(private el: ElementRef, private renderer: Renderer2,private activatedroute:ActivatedRoute, private router: Router,@Optional() private host:ProductDetailsComponent) {
    
   }

  //  @HostListener('click', ['$event']) onClick($event){
  //    const productId = this.products.Id;
  //    this.router.navigate(['/proDetails/:Id']);
  //  }
           

   ngOnInit() {
    var button= this.renderer.createElement('button');
    var text = this.renderer.createText('ViewDetails');
    this.renderer.appendChild(button, text);
    this.renderer.appendChild(this.el.nativeElement,button);
  
   }

}
