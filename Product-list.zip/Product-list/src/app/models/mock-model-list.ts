import { ProductModel } from '../models/product-model';

export const PRODUCTS : ProductModel[]=[
    {
      Id: 101,
        'Name': 'Nokia7.2',
       'Image': "../../assets/nokia_7_2-front_back-cyan_green.png",
       'Price': 25000,
       'Desc':`The powerful Qualcomm® Snapdragon™ 660
      processor combined with the latest Android™ 9 Pie 
      operating system means you can go without charging for 
      up to two days.1 Nokia 7.2 also features AI-assisted Adaptive
      Battery which prioritizes battery life to the apps you use the most.`},
      {
      Id: 102,
        'Name': 'Samsungs20',
       'Image': '../assets/Samsung-Galaxy-S20-FE-5G-Cloud-Navy-thumbnail.png',
       'Price':50000,
       'Desc':`The Samsung Galaxy S20 FE 5G is packed with all the fan favorite features of a Galaxy series 
      device at an even more accessible price! With a beautiful 6.5” FHD+ Super AMOLED screen, smooth 
      120Hz display, bold color options, pro-grade triple rear camera, 32MP selfie camera, and an 
      all-day 4500 mAh intelligent battery that charges up in minutes, the Galaxy S20 FE 5G delivers uncompromised 
      innovation. Experience the new Samsung Galaxy S20 FE 5G and all its awesome features on the largest nationwide 5G network.`
    },
      {
        Id: 103,
        'Name': 'Nokia9',
       'Image': '../assets/nokia_9-en_int-Recommended.png',
       'Price':25000,
       'Desc':`Nokia9 Designed with photographers in mind, the #Nokia9PureView captures an incredible amount 
      of detail. These content creators got behind the five cameras to create some magic of their own.`},
      {
        Id: 104,
        'Name': 'SonyEricson10',
       'Image': '../assets/sonyericsonXperia10.webp',
       'Price':28000,
       'Desc':`New Sony Xperia 10 II 128GB XQ-AU52 Dual SIM GSM Factory Unlocked 4G LTE 6" OLED 
      Display 4GB RAM Triple Camera Smartphone - Berry Blue - International Version`},
      {
        Id: 105,
        'Name': 'Iphone11',
       'Image': '',
       'Price':60000,
       'Desc':`A new dual‑camera system captures more of what you see and love. The fastest 
      chip ever in a smartphone and all‑day battery life let you do more and charge less. And the 
      highest‑quality video in a smartphone, so your memories look better than ever.`},
      {
        Id: 106,
        'Name': 'SamsungNote',
       'Image': '../assets/Samsung-Galaxy-Note20-5G-Mystic-Gray-thumbnail.png',
       'Price':75000,
       'Desc':`The power to work. The power to play. The Samsung Galaxy Note20 5G has a beautiful 6.7” 
      FHD+ flat display, pro-grade cameras, and a powerful battery. This isn't the time to slow down, 
      this is the time to forge ahead and take the opportunities that come your way. You don’t need 
      a smartphone. You need a power phone. One as beautiful as it is intelligent with a pen that is 
      mightier, a battery that doesn't leave you hanging and is as well-connected as you. The Galaxy 
      Note20 5G takes power to the next level with cutting-edge technology, letting you master whatever 
      you choose to do next, and keeping you connected on America’s largest 5G network.`},
      {
        Id: 107,
        'Name': 'SonyEricsonXperiapro5g',
       'Image': '../assets/sonyericsonXperiaPro5g.webp',
       'Price':45000,
       'Desc':`The Xperia PRO is a tool you can rely on when you’re out in the field. Robust and durable, 
      it combines IP65/68 rating4 water and dust resistance with Corning® Gorilla® Glass 6 on the front 
      for protection. On the back, the low dielectric constant material helps maintain a reliable connection
      by allowing 5G mmWave radio signals to pass through more easily.`},
      {
        Id: 108,
        'Name': 'Iphone11pro',
       'Image': '../assets/iphone11pro.png',
       'Price':100000,
       'Desc':`Meet the first triple‑camera system to combine cutting‑edge technology with the 
      legendary simplicity of iPhone. Capture up to four times more scene. Get beautiful images in 
      drastically lower light. Shoot the highest‑quality video in a smartphone — then edit with the 
      same tools you love for photos. You’ve never shot with anything like it.`}
    ];

