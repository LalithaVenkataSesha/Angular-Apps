export class ProductModel {
    public Id: any;
    public Name: any;
    public Image: any;
    public Price: number;
    public Desc: any;
  static Id: any;
}
