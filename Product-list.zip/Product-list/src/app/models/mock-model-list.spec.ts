import { MockModelList } from './mock-model-list';

describe('MockModelList', () => {
  it('should create an instance', () => {
    expect(new MockModelList()).toBeTruthy();
  });
});
