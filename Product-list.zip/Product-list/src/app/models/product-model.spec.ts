import { ProductModel } from './product-model';

describe('ProductModel', () => {
  it('should create an instance', () => {
    expect(new ProductModel()).toBeTruthy();
  });
});
