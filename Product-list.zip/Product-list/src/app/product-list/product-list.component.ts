import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit, ɵRender3ComponentFactory} from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from '../models/product-model';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
  // productList: any;
  Products: ProductModel;

  constructor(private router: Router) {}
    //  const Id = this.Products.Id;
    productList = [
      {'Id':101,'Name': 'Nokia7.2','Price': 25000},
      {'Id':102,'Name': 'Samsungs20','Price':50000},
      {'Id':103,'Name': 'Nokia9','Price':25000},
      {'Id':104,'Name': 'SonyEricson10','Price':28000},
      {'Id':105,'Name': 'Iphone11','Price':60000},
      {'Id':106,'Name': 'Samsung','Price':75000},
      {'Id':107,'Name': 'SonyEricsonXperiapro5g','Price':45000},
      {'Id':108,'Name': 'Iphone11pro','Price':100000}
    ]

  
  
  ngOnInit(): void {
   
}
onSelect(pro){
  console.log(pro.Id);
  this.router.navigate(['/proDetails', pro.Id]);
}

}
