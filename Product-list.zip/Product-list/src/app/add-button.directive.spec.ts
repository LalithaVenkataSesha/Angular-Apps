import { AddButtonDirective } from './add-button.directive';

describe('AddButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new AddButtonDirective();
    expect(directive).toBeTruthy();
  });
});
