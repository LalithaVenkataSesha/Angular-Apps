import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ContactComponent } from './contact/contact.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

const routes: Routes = [
  { path: 'proList', component:ProductListComponent },
  { path: 'proDetails/:id', component:ProductDetailsComponent },
  { path: 'contact', component:ContactComponent },
  { path: '**', component: PagenotfoundComponent }  // Wildcard route for a 404 page
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [
  ProductDetailsComponent,
  ProductListComponent,
  ContactComponent,
  PagenotfoundComponent
]