import { Component, OnInit } from '@angular/core';
import { Route,ActivatedRoute, Router, ActivatedRouteSnapshot } from '@angular/router';
import { ProductListComponent } from '../product-list/product-list.component';
import { PRODUCTS } from '../models/mock-model-list';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
productList = PRODUCTS;

  constructor(private route: Router) {
  }
  ngOnInit(): void {
  }

}
