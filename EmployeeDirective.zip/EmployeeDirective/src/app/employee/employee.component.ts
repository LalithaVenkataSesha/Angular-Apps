import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
@Input() EmployeeDta: [];
  EmployeeData = [
    {
      'EmployeeID': '1',
      'FirstName': 'Mark',
      'LastName': 'Otto',
      'Dept': 'IT',
      'City': 'Santa Clara',
      'Email': 'MOtto@gmail.com'
    },
    {
      'EmployeeID': '2',
      'FirstName': 'Jacob',
      'LastName': 'Thornton',
      'Dept': 'Revenue',
      'City': 'San Antonio',
      'Email': 'ThorntonJac@gmail.com'
    },
    {
      'EmployeeID': '3',
      'FirstName': 'Larry',
      'LastName': 'the Bird',
      'Dept': 'Developer',
      'City': 'Santa Rosa',
      'Email': 'BirdLarry@yahoo.com'
    },
    {
      'EmployeeID': '4',
      'FirstName': 'William',
      'LastName': 'smith',
      'Dept': 'Construction',
      'City': 'Edison',
      'Email': 'Wsmith@gmail.com'
    },
    {
      'EmployeeID': '5',
      'FirstName': 'Sandra',
      'LastName': 'leonardo',
      'Dept': 'Banking',
      'City': 'Princeton',
      'Email': 'leoSandra@gmail.com'
    },
  ];
  
  constructor() { }

  ngOnInit(): void {
  }

}
