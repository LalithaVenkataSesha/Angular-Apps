
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appcolor]',
})
export class ColorDirective {
    
constructor(private el: ElementRef){}
  // this.el.nativeElement.mouseenter.backgroundcolor = 'lime';

  @HostListener ('mouseenter')
      onmouseover() {

    this.el.nativeElement.style.backgroundColor = 'CadetBlue';

  }
  @HostListener ('mouseleave') 
      onmouseleave() {
    this.el.nativeElement.style.backgroundColor = 'initial';

      }

}
  



