import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { NGXBootstrap } from 'ngx-bootstrap';
import { AppComponent } from './app.component';
import { ColorDirective } from './directives/color.directive';
import { EmployeeComponent } from './employee/employee.component';

@NgModule({
  declarations: [
    AppComponent,
    ColorDirective,
    EmployeeComponent
  ],
  imports: [
    BrowserModule
    // NGXBootstrap
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
