import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
// import { EmpListComponent } from './emp-list/emp-list.component';
import { EmployeetableComponent } from './employeetable/employeetable.component';

@NgModule({
  declarations: [
    AppComponent,
    // EmpListComponent,
    EmployeetableComponent,
    
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
