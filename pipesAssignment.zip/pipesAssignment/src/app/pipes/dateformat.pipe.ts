import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'dateformat'
})
export class DateformatPipe extends 
DatePipe implements PipeTransform  {
  Dob: string;
  transform(Dob: string) {
     var value = this.transform('MM/dd/yyyy');
     return value;
 }
 // return null;
  // }

}
