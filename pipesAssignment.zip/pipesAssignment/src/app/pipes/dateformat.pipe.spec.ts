import { DateformatPipe } from './dateformat.pipe';

describe('DateformatPipe', () => {
  it('create an instance', () => {
    const pipe = new DateformatPipe();
    expect(pipe).toBeTruthy();
  });
});
