import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-table',
  templateUrl: './employee-table.component.html',
  styleUrls: ['./employee-table.component.css']
})
export class EmployeeTableComponent implements OnInit {

  constructor() { }

  employees = [

    {
      'EmployeeID': '1',
      'FirstName': 'Mark',
      'LastName': 'Otto',
      'Dob' : new Date(1985, 10, 21),
      'Dept': 'IT',
      'City': 'Santa Clara',
      'Email': 'MOtto@gmail.com',
      'Salary': '75000'
    },
    {
      'EmployeeID': '2',
      'FirstName': 'Jacob',
      'LastName': 'Thornton',
      'Dob' :  new Date(1975, 10, 27),
      'Dept': 'Revenue',
      'City': 'San Antonio',
      'Email': 'ThorntonJac@gmail.com',
      'Salary': '125000'
    },
    {
      'EmployeeID': '3',
      'FirstName': 'Larry',
      'LastName': 'the Bird',
      'Dob' :  new Date(1980, 10, 30),
      'Dept': 'Developer',
      'City': 'Santa Rosa',
      'Email': 'BirdLarry@yahoo.com',
      'Salary': '100000'
    },
    {
      'EmployeeID': '4',
      'FirstName': 'William',
      'LastName': 'smith',
      'Dob' :  new Date(1978, 7, 15),
      'Dept': 'Construction',
      'City': 'Edison',
      'Email': 'Wsmith@gmail.com',
      'Salary': '120000'
    },
    {
      'EmployeeID': '5',
      'FirstName': 'Sandra',
      'LastName': 'leonardo',
      'Dob' :  new Date(1982, 8, 21),
      'Dept': 'Banking',
      'City': 'Princeton',
      'Email': 'leoSandra@gmail.com',
      'Salary': '150000'
    },
  ];

  ngOnInit(): void {
  }

}
