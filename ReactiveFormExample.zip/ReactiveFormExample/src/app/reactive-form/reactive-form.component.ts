import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  SignupForm: FormGroup;
  constructor() { }

  ngOnInit(): void {

    this.SignupForm = new FormGroup({
      'userData': new FormGroup({
        'fullName': new FormControl(null),
        'email': new FormControl(null),
        'address': new FormControl(null),
        'city': new FormControl(null),
        'phoneno': new FormControl(null),
        'password': new FormControl(null),
        'confirmpassword': new FormControl(null),
      }),
    });

    this.SignupForm.setValue({
      'userData': {
        'fullName': '',
        'email': '',
        'address': '',
        'city': '',
        'phoneno': '',
        'password': '',
        'confirmpassword': ''
      }

    })

  }
  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.SignupForm.value));
    console.warn(this.SignupForm.value);
  }

}
