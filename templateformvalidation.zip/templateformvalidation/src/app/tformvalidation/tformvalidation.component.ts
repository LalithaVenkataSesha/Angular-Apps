import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tformvalidation',
  templateUrl: './tformvalidation.component.html',
  styleUrls: ['./tformvalidation.component.css']
})
export class TformvalidationComponent implements OnInit {
  model: any = {};
  constructor() { }
  
  displayForm() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model));
  }
  ngOnInit(): void {
  }

}
