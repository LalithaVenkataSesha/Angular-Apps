import { Component, OnInit } from '@angular/core';
import { EmployeeDetailsService } from '../../../services/employee-details.service';
import { Employee2 } from '../../../models/employee2';

@Component({
  selector: 'app-new-employee',
  templateUrl: './new-employee.component.html',
  styleUrls: ['./new-employee.component.css']
})
export class NewEmployeeComponent implements OnInit {
  employees: Employee2[];
  errorMessage: string;

  constructor(public EmployeeService: EmployeeDetailsService) { }

  ngOnInit() {
    this.EmployeeService.getEmployeeData()
    .subscribe(emplist => {
      this.employees = emplist;
    },
    err => this.errorMessage = <any> err
  );
  }

}
