import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';
import { NewEmployeeComponent } from './components/new-employee/new-employee.component';
import { EmployeeDetailsService } from '../services/employee-details.service';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeDetailsComponent,
    NewEmployeeComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [EmployeeDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
