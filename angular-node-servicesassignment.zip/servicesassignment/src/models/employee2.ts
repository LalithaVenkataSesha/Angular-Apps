export class Employee2 {
    public id: any;
    public employee_name: any;
    public employee_salary: any;
    public employee_age: any;
    public profile_image: any;
}
