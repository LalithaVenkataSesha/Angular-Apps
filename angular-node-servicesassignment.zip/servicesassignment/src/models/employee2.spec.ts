import { Employee2 } from './employee2';

describe('Employee2', () => {
  it('should create an instance', () => {
    expect(new Employee2()).toBeTruthy();
  });
});
