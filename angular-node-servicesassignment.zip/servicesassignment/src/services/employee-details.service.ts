import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee2 } from '../models/employee2';
import { HttpClient } from '@angular/common/http';
import { tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  constructor(public http: HttpClient) { }
  private employeeData: Array<Employee2> 
       
  getEmployeeData():Observable<Employee2[]> {
    return this.http.get<Employee2[]>('http://localhost:3000/empData');
    // .pipe(tap(data => console.log("Employees" + JSON.stringify(data))));
  }

  
}
